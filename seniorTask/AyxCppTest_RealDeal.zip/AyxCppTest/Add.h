#pragma once
#include <string>

namespace AyxCppTest
{
	extern std::string Add(std::string lhs, std::string rhs);
}